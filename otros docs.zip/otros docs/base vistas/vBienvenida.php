<!DOCTYPE html>
<html lang="en">
<head>  
    <title>Bienvenida</title>   
</head>
<body>
    <a href="../Home/registro">Registrarse</a>
    <br>
    <a href="../Home/ingreso">Ingresar</a> 
    <br>
    <a href="../Home/mostrarRegistros">Registros</a> 
</body>
</html>