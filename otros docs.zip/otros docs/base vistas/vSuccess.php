<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>
</head>
<body>
    <div class="container">
        <p>El usuario se registro con exito,
            su identificador es el:
                <?php echo$idRegistrado; ?></p>

    </div>
    <footer>
<div class="text-center text-dark p-3" style="background-color: #97A3AB ">
Luis Osvaldo Rodriguez Ramirez y Cesar Gabriel Reyes Rodriguez
</div>

</footer>

</body>

</html>