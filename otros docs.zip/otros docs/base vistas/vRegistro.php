<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
  <form method="POST" action="../Home/insertarForm">
    <div class="container">
    <h1>registro usuarios</h1>
    <label for="nombre">nombre</label>
    <input type="text" id="nombre" name="nombre"><br>
    <label for="apellido">apellido</label>
    <input type="text" id="apellido" name="apellido"><br>
    <label for="email">Email</label>
    <input type="email" id="correo" name="correo" 
        placeholder="email@example.com"><br>
    <label for="password">Password</label>
    <input type="password" id="contraseña" name="contraseña"><br>



        <button type="submit"> Registrar </button>
    </form>
</div><br>
<footer>
<div class="text-center text-dark p-3" style="background-color: #97A3AB ">
 Luis Osvaldo Rodriguez Ramirez y Cesar Gabriel Reyes Rodriguez
</div>

</footer>
</body>
</html>
<?php


?>
