<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 <div class="container">
     <h1>Registro encontrado</h1>
     <form method="POST" action="<?php echo base_url(); ?>/TP_web/public/Home/actualizarRegistro">
     <input type="hidden" id="id_usuario" name="id_usuario" value="<?php echo $id_usuario; ?>">
     <label for="correo">Correo</label>
     <input type="correo" name="correo" value="<?php echo $correo; ?>">
     <label for="password"> contraseña</label>
     <input type="text" name="contraseña" value="<?php echo $contraseña; ?>">

     <button type="submit">Actualizar</button>
</div>
</body>
</html>