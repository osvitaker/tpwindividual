<?php

namespace App\Controllers;
use App\Models\mFacturas;

class Home extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }
    public function registro(){
        return view ('vRegistro');
    }
    public function insertarForm(){
        $mFacturas = new mFacturas();
        $subT= $_POST['pu_del_articulo']*$_POST['cantidad_del_articulo'];
        $facturanueva = [
            "fecha_de_compra"=>$_POST['fecha_de_compra'],
            "descripcion_del_articulo"=>$_POST['descripcion_del_articulo'],
            "cantidad_del_articulo"=>$_POST['cantidad_del_articulo'],
            "pu_del_articulo"=>$_POST['pu_del_articulo'],
            "subtotal_articulo"=>$subT
        ];
        $mFacturas->insert($facturanueva);
        $datoId['idRegistrado'] = $mFacturas->db->insertID();
        return view("vSuccess", $datoId);

    }
     public function mostrarRegistros()
    {
      $mFacturas=new mFacturas();
      $all=$mFacturas->findAll();
      $materiales= array('materiales' =>$all);
      return view("vRegistros",$materiales);
    }
    public function eliminarRegistro($id)
    {
      $mUsuarios = new mUsuarios();
      $id_usuario = $id;
      $mUsuarios->delete($id_usuario);
      
      return $this->mostrarRegistros();
    }

}