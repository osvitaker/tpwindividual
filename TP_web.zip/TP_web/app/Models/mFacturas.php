<?php 
namespace App\Models;
use CodeIgniter\Model;
class mFacturas extends Model
{
	protected $table = 'materiales';
	protected $primaryKey = 'id_factura';

	protected $useAutoIncrement = true;

	protected $returnType = 'array';
	protected $useSoftDeletes = false;

	protected $allowedFields = ['fecha_de_compra', 'descripcion_del_articulo','cantidad_del_articulo','pu_del_articulo','subtotal_articulo'];

	protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;
}
?>