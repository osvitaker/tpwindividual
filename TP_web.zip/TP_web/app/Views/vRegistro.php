<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
  <form method="POST" action="../Home/insertarForm">
    <div class="container">
    <h1>registro de materiales</h1>
    <label for="fecha_de_compra">fecha de compra</label>
    <input type="date" id="fecha_de_compra" name="fecha_de_compra"><br>
    <label for="descripcion_del_articulo">descripcion del articulo</label>
    <input type="text" id="descripcion_del_articulo" name="descripcion_del_articulo"><br>
    <label for="cantidad_del_articulo">cantidad del articulo</label>
    <input type="number" id="cantidad_del_articulo" name="cantidad_del_articulo" ><br>
    <label for="pu_del_articulo">precio unitario del articulo</label>
    <input type="number" id="pu_del_articulo" name="pu_del_articulo"><br>



        <button type="submit"> Registrar factura </button>
    </form>
</div><br>
<footer>
<div class="text-center text-dark p-3" style="background-color: #97A3AB ">
 Luis Osvaldo Rodriguez Ramirez
</div>

</footer>
</body>
</html>
<?php


?>
