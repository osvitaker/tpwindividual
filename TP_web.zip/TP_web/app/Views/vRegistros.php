<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Registros</title>
</head>
<body>
	<div class="container">
    <h1>Resgistros Actuales</h1>
    <table border=1>
      <thead>
        <tr>
          <th>ID</th>
          <th>fecha de compra</th>
          <th>descripcion del articulo</th>
          <th>Cantidad del articulo</th>
          <th>precio unitario del articulo</th>
          <th>subtotal del articulo</th>
					<th>Eliminar</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($materiales as $factura) {?>
        <tr>
          <td><?php echo $factura['id_factura'];?></td>
          <td><?php echo $factura['fecha_de_compra'];?></td>
          <td><?php echo $factura['descripcion_del_articulo'];?></td>
          <td><?php echo $factura['cantidad_del_articulo'];?></td>
          <td><?php echo $factura['pu_del_articulo'];?></td>
          <td><?php echo $factura['subtotal_articulo'];?></td>
					<td><a type="button" href="<?php echo base_url();?>/TP_web/public/Home/eliminarRegistro/<?php echo $factura['id_factura'];?>">Eliminar</a></td>
        </tr>
      <?php } ?>
      </tbody>
    </table>
  </div>
</body>
<footer>
  <br>
  <div class="text-center textdark p-3"style="background-color: rgba(0,0,0,0.2);">
    <i class="bi bi-badge-cc"></i>2022:
    <a class="text-dark" href="<?php echo base_url();?>/TP_web/public/Home/bienvenida">Home</a>
  </div>
</footer>
</html>
